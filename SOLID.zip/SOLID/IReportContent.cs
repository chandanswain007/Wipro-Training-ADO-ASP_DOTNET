﻿// Defines the contract for report content generation
public interface IReportContent
{
    string GetContent();
}