// Defines the contract for formatting report data
public interface IReportFormatter
{
    void Format(string content);
}