// The product interface
public interface IDocument
{
    void Open();
    void Close();
}